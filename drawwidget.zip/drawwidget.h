#ifndef DRAWWIDGET_H
#define DRAWWIDGET_H
#include"geometery.h"
#include <QWidget>
#include<QApplication>
#include<QSize>
#include<QList>
#include<QDesktopWidget>
#include<QDebug>
#include<QPen>
#include<QPainter>
#include<QMouseEvent>
#include<QScreen>
#include<QString>
#include<QLabel>
#include<iostream>
#include<QTime>
#include<vector>
#include<QMap>
#include<QPushButton>
#include"buttongroup.h"
#include<QGraphicsDropShadowEffect>
static int b = 3;
static QMap<int, QPoint> point_map = {
    {1, QPoint(40*b,70*b)},
     {2, QPoint(60*b,50*b)},
     {3, QPoint(120*b,40*b)},
     {4, QPoint(100*b,130*b)},
     {5, QPoint(140*b,90*b)},
     {6, QPoint(170*b,90*b)},
     {7, QPoint(200*b,90*b)},
     {8, QPoint(140*b,150*b)},
     {9, QPoint(210*b,160*b)},
     {10, QPoint(90*b,210*b)},
     {11, QPoint(150*b,220*b)},
     {12, QPoint(160*b,290*b)},
     {13, QPoint(150*b,320*b)},
     {14, QPoint(150*b,370*b)},
     {15, QPoint(20*b,300*b)},
     {16, QPoint(40*b,340*b)},
     {17, QPoint(60*b,370*b)},
     {18, QPoint(180*b,410*b)}
};
static QList<QString> g_buttonName =
{
    "直线",
    "箭头",
    "矩形",
    "原型",
    "菱形",
    "橡皮擦",
    "文字",
    "颜色",
    "打印"
};
class drawWidget : public QWidget
{
    Q_OBJECT
public:
    explicit drawWidget(QWidget *parent = nullptr);
    ~drawWidget();
public:
    //图形类型

public:
    //工厂模式

    void selectGeometery();
protected:
    //重写的操作
    void mouseMoveEvent(QMouseEvent *event);
    void mousePressEvent(QMouseEvent *event);
    void mouseReleaseEvent(QMouseEvent *event);
    void paintEvent(QPaintEvent *event);

signals:

private:
    //判断鼠标是否按下
    bool m_isRightButtonDown = false;
    bool m_isLeftButtonDown = false;
    //图形抽象基类指针
    GeoObject* m_pSelObject = nullptr;
    GeoObject* m_pSelObjectTemp = nullptr;
    GeoObject* getGeoObject(QMouseEvent *event);
    //临时点的记录
    QPoint m_startPoint;
    QPoint m_endPoint;

    GeoObject* m_pTempGeoObject = nullptr;
    QDesktopWidget* pDesktopWidget;

    //绘图对象种类
    GEO_TYPE m_geoType;
    //对象数组
    std::vector<GeoObject*>geo_contain;
    ButtonGroup* m_buttonGroup;
    GeoFactory* m_geoFactory;
    //菜单选择
protected:

public slots:
};

#endif // DRAWWIDGET_H
