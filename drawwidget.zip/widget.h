#ifndef WIDGET_H
#define WIDGET_H
#include<windows.h>
#include<QRect>
#include <QWidget>
#include<QMouseEvent>
#include<QDesktopWidget>
#include<QDebug>
#include<QGraphicsEffect>
#include<QPaintEvent>
#include<QPainter>
#include"mainwindow.h"
#include"drawwidget.h"
#include<iostream>
namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT
public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();
protected:
    void leaveEvent(QEvent *event);
    void enterEvent(QEvent *event);
    void paintEvent(QPaintEvent *);
    void hideWidget();
    void showWidget();
    void moveWidget();
    bool isUpDownWidget();
    void onCompleteCature(QPixmap captureImage);
    //bool eventFilter(QObject *obj, QEvent *e);//重写快捷键
    bool m_status;
    bool m_mainwindowStatus;
    QRect m_rect;
    int m_divide;
    MainWindow* pMainWindow;
    drawWidget* pDrawWindow;
private slots:
    void on_pushButton_20_clicked();
    void on_pushButton_19_clicked();

    void on_pushButton_draw_clicked();

    void on_pushButton_exit_clicked();

private:
    Ui::Widget *ui;
};

#endif // WIDGET_H
