#include "point.h"

Point::Point(const Point& point_obj)
{
	m_x = point_obj.getX();
	m_y = point_obj.getY();
}

Point::Point(double x, double y)
{
	m_x = x;
	m_y = y;
}

double Point::getX() const
{
	return m_x;
}

double Point::getY() const
{
	return m_y;
}

void Point::setX(double x)
{
	this->m_x = x;
}

void Point::setY(double y)
{
	this->m_y = y;
}

void Point::print() const
{
	std::cout<< "(" << m_x << " , " << m_y << ")";
}

Point& Point::operator=(const Point& point_obj)
{
	this->m_x = point_obj.getX();
	this->m_y = point_obj.getY();
	return *this;
}

Point Point::operator+(const Point& point_obj)
{
	double x = this->m_x + point_obj.getX();
	double y = this->m_y + point_obj.getY();
	return Point(x, y);
}

Point Point::operator-(const Point& point_obj)
{
	double x = this->m_x - point_obj.getX();
	double y = this->m_y - point_obj.getY();
	return Point(x ,y);
}

bool Point::operator==(const Point& point_obj)
{
	return ((this->getX() == point_obj.getX())
		&& (this->getY() == point_obj.getY()))
		? true : false;
}

GeometeryType Point::getType() const
{
	return point_type;
}

Point operator-(const Point& point_lh, const Point& point_rh)
{
	double x = point_lh.getX() - point_rh.getX();
	double y = point_lh.getY() - point_rh.getY();
	return Point(x, y);
}

bool operator==(const Point& point_lh, const Point& point_rh)
{
	return ((point_lh.getX() == point_rh.getX()) 
		&&(point_lh.getY() == point_rh.getY()))
		? true : false;
}
