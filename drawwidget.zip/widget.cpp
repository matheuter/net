#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    this->setWindowTitle("Tiny");
    setWindowFlags(Qt::FramelessWindowHint | Qt::WindowSystemMenuHint);
    this->setFixedSize(this->width(),this->height());//固定大小
    this->setWindowFlags(Qt::Dialog | Qt::WindowStaysOnTopHint);//取消最小化按钮，并保持显示在最上方
    this->
    m_status = true;
    m_mainwindowStatus = false;

    QString style = QString("QPushButton{background-color:#ffffff;border:none;} "
                            "QPushButton:hover{background-color:rgba(%1, %2, %3, 40);} "
                            "QPushButton:pressed, QPushButton:checked{background-color:rgba(%1, %2, %3, 80);}").arg(10).arg(255).arg(10);
    ui->pushButton_20->setStyleSheet(style);
    ui->pushButton_19->setStyleSheet(style);
    ui->pushButton_draw->setStyleSheet(style);
    ui->pushButton_exit->setStyleSheet(style);
    ui->pushButton_20->setFixedSize(100,60);
    ui->pushButton_19->setFixedSize(100,60);
    ui->pushButton_exit->setFixedSize(100,60);
    ui->pushButton_draw->setFixedSize(100,60);
    ui->pushButton_operation->setStyleSheet(style);
    ui->pushButton_operation->setFixedSize(100,60);
    ui->pushButton_vedio->setStyleSheet(style);
    ui->pushButton_vedio->setFixedSize(100,60);
}

Widget::~Widget()
{
    if (pDrawWindow)
        delete pDrawWindow;
    if(pMainWindow)
        delete pMainWindow;
    delete ui;

}

void Widget::enterEvent(QEvent *event)
{
    m_rect = this->geometry();
    m_divide = m_rect.right() - QApplication::desktop()->rect().right();
    if ( m_status == false && m_divide > 0 && isUpDownWidget())
        showWidget();
}

void Widget::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.fillRect(rect(), QColor(255,255,255,255));
}

void Widget::leaveEvent(QEvent *event)
{
    m_rect = this->geometry();
    m_divide = m_rect.right() - QApplication::desktop()->rect().right();
    if (m_status == true && m_divide >= -10 && isUpDownWidget())
        hideWidget();
}

void Widget::hideWidget()
{
    QDesktopWidget* pDesktopWidget = QApplication::desktop();
    int position_y = (pDesktopWidget->height() - m_rect.height())/2;
    for (int i = 0; i <= m_divide; i++)
        move(pDesktopWidget->rect().right() - m_divide + i - 10,position_y*0.8);
    m_status = false;
}

void Widget::showWidget()
{
    QDesktopWidget* pDesktopWidget = QApplication::desktop();
    int position_y = (pDesktopWidget->height() - m_rect.height())/2;
    move(pDesktopWidget->rect().right() - m_divide - 9,position_y*0.8);
    m_status = true;
}

//move widget to where loaction is pos
void Widget::moveWidget()
{
    QDesktopWidget* pDesktopWidget = QApplication::desktop();
    int position_y = (pDesktopWidget->height() - m_rect.height())/2;
    move(pDesktopWidget->rect().right()- 10,position_y*0.8);
    m_status = true;
}

bool Widget::isUpDownWidget()
{
    QPoint pos = QCursor::pos();
    if (m_rect.top() > pos.y() || m_rect.bottom() < pos.y())
        return false;
    else
        return true;
}

void Widget::on_pushButton_20_clicked()
{
    if (m_mainwindowStatus == false)
    {
        moveWidget();
        pMainWindow = new MainWindow();
        pMainWindow->show();
        m_mainwindowStatus = true;
    }
    else
    {
        if (pMainWindow != nullptr)
        {
            delete pMainWindow;
        }
        moveWidget();
        pMainWindow = new MainWindow();
        pMainWindow->show();
        m_mainwindowStatus = true;
    }

}

void Widget::onCompleteCature(QPixmap captureImage)
{
    QPalette palette(this->palette());
    palette.setBrush(QPalette::Background,QBrush(captureImage));
    pMainWindow->setAutoFillBackground(true);
    pMainWindow->setPalette(palette);
}

void Widget::on_pushButton_19_clicked()
{
    if (m_mainwindowStatus == true)
    {
        pMainWindow->savePicture();
        pMainWindow->close();
        delete pMainWindow;
        m_mainwindowStatus = false;
    }
}

void Widget::on_pushButton_draw_clicked()
{
    pDrawWindow = new drawWidget();
    pDrawWindow->show();
}

void Widget::on_pushButton_exit_clicked()
{
    this->close();
    exit(0);
}
