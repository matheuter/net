#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent) : QWidget(parent)
{
    pDesktopWidget = QApplication::desktop();
    QRect screenRect = pDesktopWidget->screenGeometry();
    this->setGeometry(0,0,screenRect.width(),screenRect.height());
    this->setWindowFlags(Qt::FramelessWindowHint|Qt::WindowStaysOnTopHint);//去掉标题栏
    this->setAttribute(Qt::WA_QuitOnClose,false);
    initWindow();
    loadBackgroundPixmap();

    createMenu();
}

MainWindow::~MainWindow()
{
    for (auto& obj : m_imageList)
        if (obj)
            delete obj;
}

void MainWindow::initWindow()
{
    this->setMouseTracking(true);
    this->setWindowFlags(Qt::FramelessWindowHint);
    setWindowState(Qt::WindowActive | Qt::WindowFullScreen);
}

void MainWindow::loadBackgroundPixmap()
{
    QScreen *screen = QGuiApplication::primaryScreen();


    m_loadPixmap = screen->grabWindow(QApplication::desktop()->winId()); //抓取当前屏幕的图片
    m_screenwidth = m_loadPixmap.width();
    m_screenheight = m_loadPixmap.height();
}

void MainWindow::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton)
    {
        m_isMousePress = true;
        m_beginPoint = event->pos();
    }

    if (event->button() == Qt::RightButton && m_isMousePress == true)
    {

    }
    return QWidget::mousePressEvent(event);
}

void MainWindow::mouseMoveEvent(QMouseEvent* event)
{
    if (m_isMousePress)
    {
        m_endPoint = event->pos();
        update();
        //setLabelPosition(m_beginPoint, m_endPoint);
    }
    return QWidget::mouseMoveEvent(event);
}

void MainWindow::mouseReleaseEvent(QMouseEvent *event)
{
    m_endPoint = event->pos();
    m_isMousePress = false;
    return QWidget::mouseReleaseEvent(event);
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    m_painter.begin(this);                                          //进行重绘;
    QColor shadowColor = QColor(0, 0, 0, 100);                      //阴影颜色设置;
    m_painter.setPen(QPen(Qt::blue, 1, Qt::SolidLine, Qt::FlatCap));//设置画笔;
    m_painter.drawPixmap(0, 0, m_loadPixmap);                       //将背景图片画到窗体上;
    m_painter.fillRect(m_loadPixmap.rect(), shadowColor);           //画影罩效果;
    if (m_isMousePress)
    {
        QRect selectedRect = getRect(m_beginPoint, m_endPoint);
        m_capturePixmap = m_loadPixmap.copy(selectedRect);
        m_painter.drawPixmap(selectedRect.topLeft(), m_capturePixmap);
        m_painter.drawRect(selectedRect);
        m_painter.drawRect(m_endPoint.x() - 20,m_endPoint.y(),20,30);
    }
    m_painter.end();  //重绘结束;
    this->m_isCreatePix = true;
}

void MainWindow::keyPressEvent(QKeyEvent *event)
{
    if (event->key() == Qt::Key_Escape)
        close();
    if (event->key() == Qt::Key_Return || event->key() == Qt::Key_Enter)
    {
        signalCompleteCature(m_capturePixmap);
        close();
    }
}

QRect MainWindow::getRect(const QPoint &beginPoint, const QPoint &endPoint)
{
    int x, y, width, height;
    width = qAbs(beginPoint.x() - endPoint.x());
    height = qAbs(beginPoint.y() - endPoint.y());
    x = beginPoint.x() < endPoint.x() ? beginPoint.x() : endPoint.x();
    y = beginPoint.y() < endPoint.y() ? beginPoint.y() : endPoint.y();

    QRect selectedRect = QRect(x, y, width, height);

    if (selectedRect.width() == 0)
        selectedRect.setWidth(1);
    if (selectedRect.height() == 0)
        selectedRect.setHeight(1);
    return selectedRect;
}
void MainWindow::savePixmap()
{
    //生成图片名称
    QString picName = "截图";
    QTime time;
    //获取当前系统时间，用做伪随机数的种子
    time = QTime::currentTime();
    qsrand(time.hour() + time.msec() + time.second() * 1000);
    //随机字符串
    QString randStr;
    randStr.setNum(qrand());

    picName.append(randStr);
    picName.append(".jpg");
    qDebug() << "picName:" << picName << "qrand:" << qrand();
    m_capturePixmap.save(picName, "JPG");
}


void MainWindow::showMenu()
{

}

void MainWindow::createMenu()
{
    m_pMenu = new QMenu();
    m_pSavePixmap = new QAction(this);
    m_pdDstoryPixmap = new QAction(this);
    m_pdClipBoardPixmap = new QAction(this);
    m_pImage = new QAction(this);
    m_pSavePixmap->setText(tr("保存截图"));
    m_pdDstoryPixmap->setText(tr("取消截图"));
    m_pdClipBoardPixmap->setText(tr("复制截图"));
    m_pImage->setText(tr("挖取截图"));
    connect(m_pSavePixmap,&QAction::triggered,this,&MainWindow::savePicture);
    connect(m_pdDstoryPixmap,&QAction::triggered,this,&MainWindow::destoryPicture);
    connect(m_pdClipBoardPixmap,&QAction::triggered,this,&MainWindow::clipBoard);
    connect(m_pImage,&QAction::triggered,this,&MainWindow::createImageWindow);
}

void MainWindow::contextMenuEvent(QContextMenuEvent *event)
{
    m_pMenu->close();
    m_pMenu->addAction(m_pSavePixmap);
    m_pMenu->addAction(m_pdDstoryPixmap);
    m_pMenu->addAction(m_pdClipBoardPixmap);
    m_pMenu->addAction(m_pImage);
    m_pMenu->exec(QCursor::pos());
    event->accept();
}

void MainWindow::destoryPicture()
{
    this->close();
    m_isCreatePix = false;
}

void MainWindow::clipBoard()
{
    QApplication::clipboard()->setPixmap(m_capturePixmap);
    m_isCreatePix = false;
    this->close();
}
void MainWindow::savePicture()
{

    if (m_isCreatePix == true)
    {
        savePixmap();
        m_isCreatePix = false;
        qDebug()<<m_isCreatePix;
        this->close();
    }
}

bool MainWindow::returnStatus()
{
    return m_isCreatePix;
}

void MainWindow::createImageWindow()
{
    PictureBox* imageWindow = new PictureBox();
    QImage tmp_image =m_capturePixmap.toImage();
    imageWindow->setImage(tmp_image);
    imageWindow->setMode(PictureBox::AUTO_SIZE);
    imageWindow->show();
    m_isCreatePix = false;
    this->close();
}

