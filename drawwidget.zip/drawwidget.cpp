#include "drawwidget.h"

drawWidget::drawWidget(QWidget *parent) : QWidget(parent)
{
    pDesktopWidget = QApplication::desktop();
    QRect screenRect = pDesktopWidget->screenGeometry();
    this->setGeometry(0,0,screenRect.width(),screenRect.height());
    this->setWindowFlags(Qt::FramelessWindowHint);//去掉标题栏
    this->setAttribute(Qt::WA_QuitOnClose,false);
    this->setMouseTracking(true);
    //下划线高度默认2像素，颜色也是默认，位置默认在北方
        m_buttonGroup = new ButtonGroup(this);
        //设置下划线颜色
        m_buttonGroup->setButtonColor(QColor(25, 163, 9));
        //设置下划线高度
        m_buttonGroup->setLineHeight(8);
        //设置下划线高度
        m_buttonGroup->setButtonPosition(ButtonGroup::West);
        int size = g_buttonName.size();
        for (int index = 0; index < size; ++index)
        {
            QPushButton *btn = new QPushButton(this);
            btn->setCheckable(true);
            btn->setText(g_buttonName[index]);
            btn->setFixedSize(100,40);
            m_buttonGroup->addButton(btn, index);
        }
        m_buttonGroup->setGeometry(0,(screenRect.height()-size*40)/2,100,size*40);
        //connect(m_buttonGroup,SIGNAL(ButtonGroup::myButtonClicked(int)),this,SLOT(drawWidget::selectGeometery()));
}

drawWidget::~drawWidget()
{
    for (auto &obj:geo_contain)
        if (obj)
            delete obj;
}

void drawWidget::selectGeometery()
{
    int index = m_buttonGroup->getCurrentIndex();
    m_geoType = GEO_TYPE(index);
    qDebug()<<index;
}

void drawWidget::mouseMoveEvent(QMouseEvent *event)
{

    if (m_pSelObject != nullptr)
    {
        if (m_isLeftButtonDown == true){
            m_pTempGeoObject = this->getGeoObject(event);
            if (m_pTempGeoObject)
                m_pTempGeoObject->m_isSelect = true;
            m_pTempGeoObject = m_pSelObject;
            if (m_isLeftButtonDown == true)
            {
                m_pSelObject->changeSize(event,Action::ACT_MOVE);
            }
        }
    }/*else{
        if (m_pTempGeoObject)
            m_pTempGeoObject->m_isSelect = false;
        GeoObject* temp = getGeoObject(event);
        if (temp){
            m_pTempGeoObject = temp;
            temp->m_isSelect = true;
        }
    }*/
    update();
}
void drawWidget::mousePressEvent(QMouseEvent *event)
{
    m_geoType = GEO_TYPE(m_buttonGroup->getCurrentIndex());
    switch(event->button())
    {
    case Qt::LeftButton:
        m_isLeftButtonDown = true;
        m_pSelObject = nullptr;
        m_pSelObject = getGeoObject(event);
        if (m_pSelObject != nullptr)
        {
            m_pSelObject->m_isDraw = false;
            m_pSelObject->changeSize(event,Action::ACT_PRESS);
        }
        else
        {
            m_startPoint = event->pos();
            m_endPoint = m_startPoint;
            m_pTempGeoObject = GeoFactory::getGeoObject(m_geoType,m_startPoint,m_endPoint);
            geo_contain.push_back(m_pTempGeoObject);
            m_pSelObject = m_pTempGeoObject;
        }
    default:
        break;
    }
    update();
}
void drawWidget::mouseReleaseEvent(QMouseEvent *event)
{
    switch(event->button())
    {
    case Qt::LeftButton:
        m_isLeftButtonDown = false;
        if (m_pSelObject != nullptr)
        {
            m_pSelObject->changeSize(event,Action::ACT_RELEASE);
            m_pSelObject->m_isDraw = true;
            m_pSelObject->m_isEndPoint = false;
            m_pSelObject->m_isStartPoint = false;
            m_pSelObject->m_isLine = false;
        }
    default:
        break;
    }
    m_pSelObject = nullptr;
    update();
}
void drawWidget::paintEvent(QPaintEvent *event)
{
    QPainter* painter = new QPainter(this);
    painter->setPen(QPen(Qt::blue, 10, Qt::SolidLine, Qt::FlatCap));//设置画笔;
    for (auto& obj :this->geo_contain)
    {
        if (obj->m_isDraw = true)
        {
            painter->setPen(QPen(Qt::blue, 4, Qt::SolidLine, Qt::FlatCap));//设置画笔;
            obj->drawObject(painter);
        }
    }
    for (int i = 0; i < 18;i ++){
        painter->drawEllipse(point_map[i+1].y(),point_map[i+1].x(),10,10);
    }
    update();
}

GeoObject *drawWidget::getGeoObject(QMouseEvent *event)
{
    for (auto& obj :this->geo_contain)
    {
        if (obj->getObjectStatus(event) != GeometeryStatus::STAY_NULL)
        {
            return obj;
        }
    }
    return nullptr;
}

