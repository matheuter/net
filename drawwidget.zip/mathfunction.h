#ifndef MATHFUNCTION_H
#define MATHFUNCTION_H
#include<QPoint>
#include<math.h>
static double square(const double num){return num * num;}

// 计算屏幕上面两个点之间的直线距离的函数，需要与计算平方函数同时使用;
static double TwoPtDistance(const QPointF& pt1, const QPointF& pt2)
{
    return sqrt(double(square(pt2.x() - pt1.x()) + square(pt2.y() - pt1.y())));
}
// 计算点到直线距离
static double PointToLine(QPoint a_,QPoint b_,QPoint c_)
{
    double res,a,b,c;//以双精度保存变量
    double x1 = a_.x();
    double x2 = b_.x();
    double y1 = a_.y();
    double y2 = b_.y();
    double x0 = c_.x();
    double y0 = c_.y();
    a=(x0-x1)*(y2-y1);//分子的左半部分
    b=(y0-y1)*(x1-x2);//分子的右半部分
    c=a+b;//二者相加
    c*=c;//平方(pow(c,2)貌似在这里更加麻烦)
    a=pow(y2-y1,2);//分母左半部分
    b=pow(x1-x2,2);//分母右半部分
    c/=(a+b);//分子分母相除
    res=sqrt(c);//开方
    return res;
}
#endif // MATHFUNCTION_H
