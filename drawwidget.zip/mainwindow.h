#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QWidget>
#include<QApplication>
#include<QSize>
#include<QDesktopWidget>
#include<QDebug>
#include<QPen>
#include<QPainter>
#include<QMouseEvent>
#include<QScreen>
#include<QLabel>
#include<iostream>
#include<QTime>
#include<QMenu>
#include<QAction>
#include<QClipboard>
#include"image.h"
#include<QList>
class MainWindow : public QWidget
{
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
Q_SIGNALS:
    void signalCompleteCature(QPixmap catureImage);
protected:
    void initWindow();
    void loadBackgroundPixmap();

    void mousePressEvent(QMouseEvent *event);
    void mouseMoveEvent(QMouseEvent* event);
    void mouseReleaseEvent(QMouseEvent *event);
    void keyPressEvent(QKeyEvent *event);
    void paintEvent(QPaintEvent *event);

    QRect getRect(const QPoint &beginPoint, const QPoint &endPoint);
protected:
    void contextMenuEvent(QContextMenuEvent *event);
private:
    //鼠标是否按下
    bool m_isMousePress = false;
    bool m_isCreatePix = true;
    //截图
    QPixmap m_loadPixmap, m_capturePixmap;
    //屏幕长宽
    int m_screenwidth;
    int m_screenheight;
    //截图起始与终止
    QPoint m_beginPoint, m_endPoint;

    QPainter m_painter;

    //右键菜单
    QMenu* m_pMenu;
    QAction* m_pSavePixmap;
    QAction* m_pdDstoryPixmap;
    QAction* m_pdClipBoardPixmap;
    QAction* m_pImage;

public:
    //右键菜单
    void showMenu();
    //创建右键菜单
    void createMenu();
    //保存图片
    void savePixmap();
    void savePicture();
    void destoryPicture();
    //复制截图到剪切板
    void clipBoard();
    bool returnStatus();

    void createImageWindow();
private:
    bool isOpenStatus = false;
    QDesktopWidget* pDesktopWidget;
    QList<PictureBox*> m_imageList;
public slots:

};

#endif // MAINWINDOW_H
