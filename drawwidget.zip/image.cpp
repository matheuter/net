#include "image.h"
#include <QPainter>
#include <QDebug>
static const int IMAGE_WIDTH = 160;
static const int IMAGE_HEIGHT = 120;
static const QSize IMAGE_SIZE = QSize(IMAGE_WIDTH, IMAGE_HEIGHT);

PictureBox::PictureBox(QWidget *parent) : QWidget(parent)
{
    m_pixmap = QPixmap(IMAGE_SIZE);
    m_pixmap.fill();
    m_scale = 1.0;
    m_mode = FIXED_SIZE;
    m_brush = QBrush(Qt::white);
    m_button = new QPushButton(this);
    QString style = QString("QPushButton{background-color:rgba(%1, %2, %3, 0);border:none;}"
        "QPushButton:hover{background-color:rgba(%1, %2, %3, 40);}"
        "QPushButton:pressed, QPushButton:checked{background-color:rgba(%1, %2, %3, 80);}").arg(10).arg(255).arg(10);

    m_button->setStyleSheet(style);
    m_button->setFixedSize(30,30);
    this->setWindowFlags(Qt::FramelessWindowHint|Qt::WindowStaysOnTopHint);//去掉标题栏
    //this->setWindowFlags(Qt::Tool);
    connect(m_button,SIGNAL(clicked(bool)),this,SLOT(close()));
    //this->setWindowOpacity(0.7);//设置透明1-全体透明
    this->setAttribute(Qt::WA_TranslucentBackground, true);//设置透明2-窗体标题栏不透明,背景透明
}

void PictureBox::setBackground(QBrush brush)
{
    m_brush = brush;
    update();
}

void PictureBox::setMode(PB_MODE mode)
{
    m_mode = mode;
    if(m_mode == AUTO_SIZE)
    {
        resize(m_pixmap.size() * m_scale);
    }
    else
    {
        setMaximumSize(QWIDGETSIZE_MAX, QWIDGETSIZE_MAX);
        setMinimumSize(0, 0);
    }
    update();
}

bool PictureBox::setImage(QImage &image, double scale)
{
    if(image.isNull())
    {
        return false;
    }
    m_pixmap = QPixmap::fromImage(image);
    m_scale = qBound(0.01, scale, 100.0);
    if(m_mode == AUTO_SIZE)
    {
        resize(m_pixmap.size() * m_scale);
    }
    m_loadPixmap = m_pixmap;
    update();
    return true;
}

void PictureBox::paintEvent(QPaintEvent * event)
{
    Q_UNUSED(event);
    QPainter painter(this);
    painter.setBackground(m_brush);
    painter.eraseRect(rect());

    double window_width, window_height;
    double image_width, image_height;
    double r1, r2, r;
    int offset_x, offset_y;
    switch (m_mode)
    {
    case FIXED_SIZE:
    case AUTO_SIZE:
        painter.scale(m_scale, m_scale);
        painter.drawPixmap(0, 0, m_pixmap);
        break;
    case FIX_SIZE_CENTRED:
        window_width = width();
        window_height = height();
        image_width = m_pixmap.width();
        image_height = m_pixmap.height();
        offset_x = (window_width - m_scale * image_width) / 2;
        offset_y = (window_height - m_scale * image_height) / 2;
        painter.translate(offset_x, offset_y);
        painter.scale(m_scale, m_scale);
        painter.drawPixmap(0, 0, m_pixmap);
        break;
    case AUTO_ZOOM:
        window_width = width();
        window_height = height();
        image_width = m_pixmap.width();
        image_height = m_pixmap.height();
        r1 = window_width / image_width;
        r2 = window_height / image_height;
        r = qMin(r1, r2);
        offset_x = (window_width - r * image_width) / 2;
        offset_y = (window_height - r * image_height) / 2;
        painter.translate(offset_x, offset_y);
        painter.scale(r, r);
        painter.drawPixmap(0, 0, m_pixmap);
        break;
    }
    update();
}


void PictureBox::mousePressEvent(QMouseEvent *event)
{
//    if (event->button()== Qt::LeftButton){
//        m_isLeftButtonDown = true;
//        m_begin = event->globalPos() - mapToGlobal(QPoint(0,0));
//    }
//    m_mousePos = event->pos();
//    m_windowPos =
    px=event->x();
    py=event->y();//记录鼠标相对窗口坐标
    pxx=geometry().width();//窗口宽度
    pyy=geometry().height();//窗口高度
    hx=geometry().x();
    hy=geometry().y();//记录鼠标按下时窗口属性，窗口左上点坐标（hx，hy）
    kx=cursor().pos().x();
    ky=cursor().pos().y();//记录鼠标全局坐标（大概有别的记录鼠标的方法但是我不会QwQ
    update();
}

void PictureBox::mouseReleaseEvent(QMouseEvent *event)
{
    update();
}

void PictureBox::mouseMoveEvent(QMouseEvent *event)
{
    if(py>pyy-20&&py<pyy&&px>pxx-20&&px<pxx)//右下角（拉长、宽
    {
       double wid = pxx+event->x()-px;
       this->setGeometry(hx,hy,pxx+event->x()-px,(pyy)*wid/pxx);
       m_pixmap=m_loadPixmap.scaled(this->size(),Qt::IgnoreAspectRatio);
    }
    if(px>0&&px<pxx-20&&py>0&&py<pyy-20)//中间区域（拖拽
    {
       this->setGeometry(hx+cursor().pos().x()-kx,hy+cursor().pos().y()-ky,pxx,pyy);
    }
    update();
}

PictureBox::~PictureBox()
{

}
