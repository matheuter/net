#ifndef BUTTONGROUP_H
#define BUTTONGROUP_H
#include<QColor>
#include <QWidget>
#include<QButtonGroup>
#include<QPropertyAnimation>
#include<QVariant>
#include<QPaintEvent>
#include<QPushButton>
#include<QPainter>
#include<QHBoxLayout>
#include<QLayoutItem>
#include<QRect>
#include<QList>
class ButtonGroup : public QWidget
{
    Q_OBJECT
public:
    enum DIR{
        North,
        South,
        West,
        East
    };

public:
    explicit ButtonGroup(QWidget *parent = nullptr);
    ~ButtonGroup();
private:
    int m_btnPosition;
    int m_curIndex;
    int m_preIndex;
    int m_offset;
    int m_lineHeight;
    QSize m_btnSize;                  //按钮的尺寸
    QBoxLayout *m_layout;             //布局
    QButtonGroup *m_btnGroup;         //按钮组
    QList<QAbstractButton *> m_buttonLst;  //按钮集合
    QPropertyAnimation *m_animation;  //属性动画
    QColor m_lineColor;
protected:
    void paintEvent(QPaintEvent *event);
public:
    void setLineHeight(int lineHeight);
    void setButtonPosition(int position);
    void addButton(QPushButton* btn, int id);
    void setButtonColor(QColor color);
    void deleteLayout();
    int getCurrentIndex();
signals:

public slots:
    void onvalueChanged(QVariant variant);
    void onbuttonClicked(int index);
};

#endif // BUTTONGROUP_H
