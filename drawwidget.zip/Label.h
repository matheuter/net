 #ifndef LABEL_H_
#define LABEL_H_
/*
 [label类]----------------------继承自[Geometery类]
*/
#include<string>
#include"geometery.h"
#include"point.h"

using std::string;

class Label : public Geometery {
public:
	Label(const string& content, const Point& position);
	Label();
	~Label(){}

	void print()const override;
	GeometeryType getType() const override;
	
	string getContent() const;
	Point getPosition() const;
	void setContent(const string& content);
	void setPosition(Point& point_obj);
private:
	string m_szContent;
	Point m_position;
};

#endif // LABEL_H_