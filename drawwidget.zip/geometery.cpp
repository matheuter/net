#include "geometery.h"
#include<iostream>

GeometeryType Geometery::getType() const
{
	return geometery_type;
}

void Geometery::print() const
{
	std::cout << "这是基类" << std::endl;
}
//---------------------------------------------

Label::Label(const string& content, const Point& position = Point(0,0))
{
    m_position = position;
    m_szContent = content;
}

Label::Label()
{
    m_position = Point(0, 0);
    m_szContent = "\0";
}

GeometeryType Label::getType() const
{
    return label_type;
}

void Label::print() const
{
    std::cout << m_szContent << std::endl;
    std::cout << "label的位置是";
    m_position.print();
    std::cout << std::endl;
}

string Label::getContent() const
{
    return m_szContent;
}

Point Label::getPosition() const
{
    return m_position;
}

void Label::setContent(const string& content)
{
    m_szContent = content;
}

void Label::setPosition(Point& point_obj)
{
    m_position = point_obj;
}
//----------------------------------------------

//----------------------line类实现---------------------------

void Line::print() const
{
    std::cout << "这是线基类" << std::endl;
}

GeometeryType Line::getType() const
{
    return line_base_type;
}

double Line::getLength() const
{
    return 0;
}


Point Line::getPosition()
{
    return Point(0,0);
}

void Line::setPosition(const Point& point_obj)
{
}


//---------------------seqmentline类实现--------------------------

SeqmentLine::SeqmentLine(const Point& point_begin, const Point& point_end)
{
    m_point_begin = point_begin;
    m_point_end = point_end;
}

SeqmentLine::SeqmentLine(const SeqmentLine& seqment_line_obj)
{
    m_point_begin = seqment_line_obj.getPointBegin();
    m_point_end = seqment_line_obj.getPointEnd();
}

void SeqmentLine::print()const
{
    m_point_begin.print();
    m_point_end.print();
}

void SeqmentLine::setPosition(const Point& point_obj)
{
    m_point_end = (m_point_end + (point_obj - m_point_begin));
    m_point_begin = point_obj;
}

double SeqmentLine::getLength() const
{
    double x = m_point_begin.getX();
    double y = m_point_begin.getY();
    double x1 = m_point_end.getX();
    double y1 = m_point_end.getY();
    return sqrt((x - x1)*(x - x1) + ((y - y1)*(y - y1)));
}

Point SeqmentLine::getPosition()
{
    return m_point_begin;
}

Point SeqmentLine::getPointBegin() const
{
    return m_point_begin;
}

Point SeqmentLine::getPointEnd() const
{
    return m_point_end;
}

GeometeryType SeqmentLine::getType() const
{
    return seqment_line_type;
}

//--------------------polyline类实现----------------------------

PolyLine::PolyLine(int n, ...)
{
    va_list arg;
    Point temp_point_obj;
    temp_point_obj = va_arg(arg, Point);
    while (n--) {
        m_points.push_back(temp_point_obj);
    }
    va_end(arg);
}

PolyLine::PolyLine(const PolyLine& polyline_obj)
{
    int point_count = polyline_obj.getPointCount();
    for (int i = 0; i < point_count; ++i) {
        this->m_points.push_back(polyline_obj.getPoint(i));
    }
}

PolyLine PolyLine::operator=(const PolyLine& polyline_obj)
{
    int point_count = polyline_obj.getPointCount();
    for (int i = 0; i < point_count; ++i) {
        this->m_points.push_back(polyline_obj.getPoint(i));
    }
    return *this;
}

void PolyLine::print()const
{
    for (auto iter = m_points.begin(); iter < m_points.end(); ++iter) {
        iter->print();
    }
}

void PolyLine::setPosition(const Point& point_obj)
{
    for (auto iter = m_points.begin() + 1; iter < m_points.end(); ++iter) {
        *iter =*iter - m_points[0] + point_obj;
    }
    m_points[0] = point_obj;
}

void PolyLine::addPoint(const Point& point_obj, int pos)
{
    auto iter = m_points.begin();
    while (pos--) {
        iter++;
    }
    m_points.insert(iter, point_obj);
}

void PolyLine::delPoint(int pos)
{
    auto iter = m_points.begin();
    while (pos--) {
        iter++;
    }
    m_points.erase(iter);
}

double PolyLine::getLength() const
{
    double x, y, x1, y1;
    double sqrt_value_sum = 0.0;
    for (auto iter = m_points.begin(); iter < m_points.end(); ++iter) {
        auto pTemp = iter + 1;
        double x = iter->getX();
        double y = iter->getY();
        double x1 = pTemp->getX();
        double y1 = pTemp->getY();
        sqrt_value_sum += sqrt((x - x1) * (x - x1) + ((y - y1) * (y - y1)));
    }
    return sqrt_value_sum;
}

Point PolyLine::getPosition()
{
    return m_points[0];
}

Point PolyLine::getPoint(int pos) const
{
    return m_points[pos - 1];
}

int PolyLine::getPointCount() const
{
    return m_points.size();
}

GeometeryType PolyLine::getType() const
{
    return point_type;
}

//--------------------------------------------------

Point::Point(const Point& point_obj)
{
    m_x = point_obj.getX();
    m_y = point_obj.getY();
}

Point::Point(double x, double y)
{
    m_x = x;
    m_y = y;
}

double Point::getX() const
{
    return m_x;
}

double Point::getY() const
{
    return m_y;
}

void Point::setX(double x)
{
    this->m_x = x;
}

void Point::setY(double y)
{
    this->m_y = y;
}

void Point::print() const
{
    std::cout<< "(" << m_x << " , " << m_y << ")";
}

Point& Point::operator=(const Point& point_obj)
{
    this->m_x = point_obj.getX();
    this->m_y = point_obj.getY();
    return *this;
}

Point Point::operator+(const Point& point_obj)
{
    double x = this->m_x + point_obj.getX();
    double y = this->m_y + point_obj.getY();
    return Point(x, y);
}

Point Point::operator-(const Point& point_obj)
{
    double x = this->m_x - point_obj.getX();
    double y = this->m_y - point_obj.getY();
    return Point(x ,y);
}

bool Point::operator==(const Point& point_obj)
{
    return ((this->getX() == point_obj.getX())
        && (this->getY() == point_obj.getY()))
        ? true : false;
}

GeometeryType Point::getType() const
{
    return point_type;
}

Point operator-(const Point& point_lh, const Point& point_rh)
{
    double x = point_lh.getX() - point_rh.getX();
    double y = point_lh.getY() - point_rh.getY();
    return Point(x, y);
}

bool operator==(const Point& point_lh, const Point& point_rh)
{
    return ((point_lh.getX() == point_rh.getX())
        &&(point_lh.getY() == point_rh.getY()))
        ? true : false;
}

//-------------------------------------------------

GeometeryType Region::getType() const
{
    return region_type;
}

void Region::print()const
{
    std::cout << "这是region类" << std::endl;
}

double CSG::getAria() const
{
    return 0.0;
}

double CSG::getCircle() const
{
    return 0.0;
}

Point CSG::getPosition() const
{
    return Point(0, 0);
}

void CSG::setPosition(const Point& point_obj)
{
    point_obj.print();
}

void CSG::print() const
{
    std::cout << "this is CSG" << std::endl;
}

GeometeryType CSG::getType() const
{
    return csg_type;
}

Retangle::Retangle(double x, double y, double x1, double y1)
{
    m_point_begin = Point(x, y);
    m_point_end = Point(x1, y1);
}

Retangle::Retangle(const Point& point_lh, const Point& point_rh)
{
    m_point_begin = point_lh;
    m_point_end = point_rh;
}

double Retangle::getAria() const
{
    double height,wight;
    height = m_point_begin.getX() - m_point_end.getX();
    wight = m_point_begin.getY() - m_point_end.getY();
    return height * wight;
}

double Retangle::getCircle() const
{
    double height, wight;
    height = m_point_begin.getX() - m_point_end.getX();
    wight = m_point_begin.getY() - m_point_end.getY();
    return 2 *(height + wight);
}

Point Retangle::getPosition() const
{
    return m_point_begin;
}

void Retangle::setPosition(const Point& point_obj)
{
    m_point_end = m_point_end - m_point_begin + point_obj;
    m_point_begin = point_obj;
}

void Retangle::setFrom(double wight, double height)
{
    m_point_end = Point(m_point_begin.getX() + wight, m_point_begin.getY() + height);
}

GeometeryType Retangle::getType() const
{
    return retrangle_type;
}

Ellipse::Ellipse(const Point& point_obj, double major_axis, double minor_axis)
{
    m_magor_axis = major_axis;
    m_minor_axis = minor_axis;
    m_position = point_obj;
}

Ellipse::Ellipse(double pos_x, double pos_y, double major_axis, double minor_axis)
{
    m_magor_axis = major_axis;
    m_minor_axis = minor_axis;
    m_position = Point(pos_x, pos_y);
}

Ellipse::Ellipse(const Ellipse& ellipse_obj)
{
    m_magor_axis = ellipse_obj.getMajorAxis();
    m_minor_axis = ellipse_obj.getMinorAxis();
    m_position = ellipse_obj.getPosition();
}

double Ellipse::getAria() const
{
    return m_magor_axis * m_minor_axis*PI;
}

double Ellipse::getCircle() const
{
    return PI*2*m_minor_axis +4*(m_magor_axis - m_minor_axis);
}

Point Ellipse::getPosition() const
{
    return m_position;
}

void Ellipse::setPosition(const Point& point_obj)
{
    m_position = point_obj;
}

void Ellipse::setFrom(double major_axis, double minor_axis)
{
    m_magor_axis = major_axis;
    m_minor_axis = minor_axis;
}

double Ellipse::getMajorAxis() const
{
    return m_magor_axis;
}

double Ellipse::getMinorAxis() const
{
    return m_minor_axis;
}

GeometeryType Ellipse::getType() const
{
    return ellipse_type;
}

//------------------------------------------------------
GeometeryStatus LineObject::getObjectStatus(QMouseEvent *event)
{
    if (isStayLine(event) == true)
    {
        this->m_isLine = true;
        return GeometeryStatus::STAY_LINE;
    }

    if (isStayPoint(event) == true)
    {
        return GeometeryStatus::STAY_POINT;
    }

    return GeometeryStatus::STAY_NULL;
}

void LineObject::changeSize(QMouseEvent *event,Action act)
{
    isStayPoint(event);
    if (act == Action::ACT_PRESS)
    {
        point = event->pos();
        if (m_isEndPoint)
        {
            endPoint = m_endPoint;
            startPoint = m_startPoint;
        }
        else if (m_isStartPoint)
        {
            endPoint = m_startPoint;
            m_startPoint = m_endPoint;
        }
        else if (m_isLine)
        {
            endPoint = m_endPoint;
            startPoint = m_startPoint;
        }
    }
    else if (act == Action::ACT_MOVE)
    {
        point_pt = event->pos();
        if (m_isEndPoint || m_isStartPoint)
        {
            m_endPoint = point_pt;
        }
        else if (m_isLine)
        {
            double disX = point_pt.x() - point.x();
            double disY = point_pt.y() - point.y();

            m_startPoint.setX(m_startPoint.x() + disX);
            m_startPoint.setY(m_startPoint.y() + disY);

            m_endPoint.setX(m_endPoint.x() + disX);
            m_endPoint.setY(m_endPoint.y() + disY);

            point = point_pt;
        }
    }
    else if(act == Action::ACT_RELEASE)
    {

        if (m_isEndPoint || m_isStartPoint)
        {
            m_endPoint = event->pos();
        }
        else if (m_isLine)
        {
            m_isDraw = true;
            m_isEndPoint = false;
            m_isStartPoint = false;
            m_isLine = false;
        }

    }
    else if(act == Action::ACT_NEW)
    {
        m_endPoint = event->pos();
    }
}



bool LineObject::isStayLine(QMouseEvent *event)
{
    int x = event->pos().x();
    int y = event->pos().y();

    return false;
}

bool LineObject::isStayPoint(QMouseEvent *event)
{
    if (TwoPtDistance(m_startPoint,event->pos()) < 5)
    {
        this->m_isStartPoint = true;
        return true;
    }

    else if (TwoPtDistance(m_endPoint,event->pos()) < 5)
    {
        this->m_isEndPoint = true;
        return true;
    }
    else if (PointToLine(m_startPoint,m_endPoint,event->pos()) < 3)
    {
        this->m_isLine = true;
        return true;
    }
    else {
        return false;
    }
}

void LineObject::drawObject(QPainter* painter)
{
    if (m_isSelect == true)
    {
        size = 3;
    }
    painter->setPen(QPen(Qt::yellow, 7, Qt::SolidLine, Qt::FlatCap));//设置画笔;
    if (m_isStartPoint)
        painter->drawPoint(m_startPoint);
    if (m_isEndPoint)
        painter->drawPoint(m_endPoint);

    painter->setPen(QPen(Qt::black, size, Qt::SolidLine, Qt::FlatCap));//设置画笔;
    painter->drawLine(m_startPoint,m_endPoint);
}


GeometeryStatus RetangleObject::getObjectStatus(QMouseEvent *event)
{
    if (isStayLine(event) == true)
    {
        this->m_isLine = true;
        return GeometeryStatus::STAY_LINE;
    }

    if (isStayPoint(event) == true)
    {
        return GeometeryStatus::STAY_POINT;
    }

    return GeometeryStatus::STAY_NULL;
}

void RetangleObject::changeSize(QMouseEvent *event,Action act)
{
    isStayPoint(event);
    if (act == Action::ACT_PRESS)
    {
        point = event->pos();
        if (m_isEndPoint)
        {
            endPoint = m_endPoint;
            startPoint = m_startPoint;
        }
        else if (m_isStartPoint)
        {
            endPoint = m_startPoint;
            m_startPoint = m_endPoint;
        }
        else if (m_isLine)
        {
            endPoint = m_endPoint;
            startPoint = m_startPoint;
        }
    }
    else if (act == Action::ACT_MOVE)
    {
        point_pt = event->pos();
        if (m_isEndPoint || m_isStartPoint)
        {
            m_endPoint = point_pt;
        }
        else if (m_isLine)
        {
            double disX = point_pt.x() - point.x();
            double disY = point_pt.y() - point.y();

            m_startPoint.setX(m_startPoint.x() + disX);
            m_startPoint.setY(m_startPoint.y() + disY);

            m_endPoint.setX(m_endPoint.x() + disX);
            m_endPoint.setY(m_endPoint.y() + disY);

            point = point_pt;
        }
    }
    else if(act == Action::ACT_RELEASE)
    {

        if (m_isEndPoint || m_isStartPoint)
        {
            m_endPoint = event->pos();
        }
        else if (m_isLine)
        {
            m_isDraw = true;
            m_isEndPoint = false;
            m_isStartPoint = false;
            m_isLine = false;
        }

    }
    else if(act == Action::ACT_NEW)
    {
        m_endPoint = event->pos();
    }
}



bool RetangleObject::isStayLine(QMouseEvent *event)
{
    int x = event->pos().x();
    int y = event->pos().y();

    return false;
}

bool RetangleObject::isStayPoint(QMouseEvent *event)
{
    if (TwoPtDistance(m_startPoint,event->pos()) < 5)
    {
        this->m_isStartPoint = true;
        return true;
    }

    else if (TwoPtDistance(m_endPoint,event->pos()) < 5)
    {
        this->m_isEndPoint = true;
        return true;
    }
    else if (PointToLine(m_startPoint,m_endPoint,event->pos()) < 3)
    {
        this->m_isLine = true;
        return true;
    }
    else {
        return false;
    }
}

void RetangleObject::drawObject(QPainter* painter)
{
    if (m_isSelect == true)
    {
        size = 3;
    }
    painter->setPen(QPen(Qt::yellow, 7, Qt::SolidLine, Qt::FlatCap));//设置画笔;
    if (m_isStartPoint)
        painter->drawPoint(m_startPoint);
    if (m_isEndPoint)
        painter->drawPoint(m_endPoint);

    painter->setPen(QPen(Qt::black, size, Qt::SolidLine, Qt::FlatCap));//设置画笔;
    painter->drawRect(QRect(m_startPoint,m_endPoint));
}
