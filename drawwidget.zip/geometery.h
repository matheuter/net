#ifndef GEOMETERY_H_
#define GEOMETERY_H_
#include<QPoint>
#include<string>
#include<QPainter>
#include<QMouseEvent>
#include<QDebug>
#include<QWidget>
#include"mathfunction.h"
using namespace std;


/*
 【类的继承关系基本视图】
[geometery类]
 |
 +--[label类]
 |
 +--[line基类]
 |   |
 |   +---[seqline类]
 |   |
 |   +---[polyline类]
 |
 +--[region虚基类]
     |
     +--[CSG基类]
     |    |
     |    +--[retangle类]
     |    |
     |    +--[ellipse类]
     |    |
     |    +--[tangle类]未完成
     |
     +--[ployment类]未完成
*/
enum GeometeryStatus {
    STAY_LINE,
    STAY_POINT,
    STAY_NULL
};
enum GeometeryType {
    geometery_type = 0,
    point_type,
    line_base_type,
    label_type,
    seqment_line_type,
    region_type,
    csg_type,
    trangle_type,
    retrangle_type,
    ellipse_type
};

class Geometery {
public:
    virtual GeometeryType getType()const;
    virtual void print() const;
};
//------------------------------------------------------
#include<iostream>
#include<iomanip>
/*
 [point类]----------------------无基类
*/
class Point{
private:
    double m_x;
    double m_y;
public:
    Point(const Point& point_obj);
    Point(double x, double y);
    Point() = default;
    ~Point(){}

    double getX()const;
    double getY()const;
    void setX(double x);
    void setY(double y);
    void print() const;

    Point& operator=(const Point& point_obj);
    Point operator+(const Point& point_obj);
    Point operator-(const Point& point_obj);
    bool operator==(const Point& point_obj);
    friend Point operator-(const Point& point_lh, const Point& point_rh);
    friend bool operator==(const Point& point_lh, const Point& point_rh);

    GeometeryType getType() const;
};
//---------------------------------------------
class Label : public Geometery {
public:
    Label(const string& content, const Point& position);
    Label();
    ~Label(){}

    void print()const override;
    GeometeryType getType() const override;

    string getContent() const;
    Point getPosition() const;
    void setContent(const string& content);
    void setPosition(Point& point_obj);
private:
    string m_szContent;
    Point m_position;
};
//----------------------------------------------

#include<vector>
#include<cstdarg>
#include<cmath>
using std::vector;


class Line : public Geometery{
public:
    Line() = default;
    virtual double getLength() const;
    virtual Point getPosition();
    virtual void setPosition(const Point& point_obj);

    virtual void print()const override;
    virtual GeometeryType getType() const override;
};


class SeqmentLine : public Line{
public:
    SeqmentLine(const Point& point_begin, const Point& point_end);
    SeqmentLine(const SeqmentLine& seqment_line_obj);
    ~SeqmentLine(){}

    void print()const override;
    void setPosition(const Point& point_obj)override;
    double getLength()const override;
    Point getPosition()override;
    Point getPointBegin() const;
    Point getPointEnd() const;
    GeometeryType getType()const override;

    Point m_point_begin;
    Point m_point_end;
};


class PolyLine :public Line {
public:
    PolyLine(int n, ...);
    PolyLine(const PolyLine& polyline_obj);
    ~PolyLine(){}
    PolyLine operator=(const PolyLine& polyline_obj);
    void print() const override;
    void setPosition(const Point& point_obj)override;
    void addPoint(const Point& point_obj, int pos);
    void delPoint(int pos);
    double getLength() const override;
    Point getPosition() override;
    Point getPoint(int pos)const;
    int getPointCount()const;
    GeometeryType getType()const override;
private:
    vector<Point> m_points;
};

//---------------------------------------------
#define PI 3.1415926

class Region :public Geometery{
public:
    Region() = default;
    GeometeryType getType() const override;
    void print()const override;
    virtual double getAria() const = 0;
    virtual double getCircle() const = 0;
    virtual Point getPosition() const = 0;
    virtual void setPosition(const Point& point_obj) = 0;
};


class CSG :public Region {
public:
    virtual double getAria() const override;
    virtual double getCircle() const override;
    virtual Point getPosition() const override;
    virtual void setPosition(const Point& point_obj)override;
    virtual void print() const override;
    virtual GeometeryType getType()const override;
};


class Retangle :public CSG {
public:
    Retangle(double x = 0, double y = 0, double x1 = 0, double y1 = 0);
    Retangle(const Point& point_lh, const Point& point_rh);
    ~Retangle(){}
    double getAria() const override;
    double getCircle() const override;
    Point getPosition() const override;
    void setPosition(const Point& point_obj)override;
    void setFrom(double wight, double height);		//设置x形式 长与宽
    GeometeryType getType()const override;
private:
    Point m_point_begin;
    Point m_point_end;
};


class Ellipse :public CSG {
public:
    Ellipse(const Point& point_obj, double major_axis, double minor_axis);
    Ellipse(double pos_x, double pos_y, double major_axis, double minor_axis);
    Ellipse(const Ellipse& ellipse_obj);
    ~Ellipse(){}
    double getAria() const override;
    double getCircle() const override;
    Point getPosition() const override;
    void setPosition(const Point& point_obj)override;
    void setFrom(double major_axis, double minor_axis);//设置形式 长轴短轴
    double getMajorAxis()const;	//获取长轴
    double getMinorAxis()const;	//获取短轴
    GeometeryType getType()const override;
private:
    double m_magor_axis;	//长轴
    double m_minor_axis;	//短轴
    Point m_position;	//中心点
};

enum Action{
    ACT_PRESS,
    ACT_MOVE,
    ACT_RELEASE,
    ACT_NEW
};
enum GEO_TYPE
{
    TYPE_LINE,
    TYPE_TRANGLE,
    TYPE_EXIT
};
//---------------------------------------------


class GeoObject
{
public:
    bool m_isStartPoint = false;
    bool m_isEndPoint = false;
    bool m_isLine = false;
    bool m_isDraw = false;
    bool m_isSelect = false;
    QPainter m_painter;
public:
    virtual GeometeryStatus getObjectStatus(QMouseEvent *event) = 0;
    virtual void changeSize(QMouseEvent *event, Action) = 0;
    virtual bool isStayLine(QMouseEvent *event) = 0;
    virtual bool isStayPoint(QMouseEvent *event) = 0;
    virtual void drawObject(QPainter* painter) = 0;
    virtual void draw(QPoint& _a, QPoint& _b) = 0;
};

class LineObject :public GeoObject
{
public:
    GeometeryStatus getObjectStatus(QMouseEvent *event);
    void changeSize(QMouseEvent*event,Action act);
    bool isStayLine(QMouseEvent*event);
    bool isStayPoint(QMouseEvent*event);
    void drawObject(QPainter* painter);
    void draw(QPoint& a, QPoint& b){}
public:

    QPoint m_startPoint;
    QPoint m_endPoint;
    QPoint startPoint, endPoint;
    QPoint point;
    QPoint point_pt;
    int size = 2;
    LineObject(QPoint _a, QPoint _b):m_startPoint(_a),m_endPoint(_b){}
    ~LineObject();
};

class RetangleObject :public GeoObject
{
public:
    GeometeryStatus getObjectStatus(QMouseEvent *event);
    void changeSize(QMouseEvent*event,Action act);
    bool isStayLine(QMouseEvent*event);
    bool isStayPoint(QMouseEvent*event);
    void drawObject(QPainter* painter);
    void draw(QPoint& a, QPoint& b)
    {a = m_startPoint;b=m_endPoint;}
public:

    QPoint m_startPoint;
    QPoint m_endPoint;
    QPoint startPoint, endPoint;
    QPoint point;
    QPoint point_pt;
    int size = 2;
    RetangleObject(QPoint _a, QPoint _b):m_startPoint(_a),m_endPoint(_b){}
    ~RetangleObject();
};

//class LabelObject :public GeoObject
//{
//public:
//    GeometeryStatus getObjectStatus(QMouseEvent *event);
//    void changeSize(QMouseEvent*event,Action act);
//    bool isStayLine(QMouseEvent*event);
//    bool isStayPoint(QMouseEvent*event);
//    void drawObject(QPainter* painter);
//    void draw(QPoint& a, QPoint& b)
//    {a = m_startPoint;b=m_endPoint;}
//public:

//    QPoint m_startPoint;
//    QPoint m_endPoint;
//    QPoint startPoint, endPoint;
//    QPoint point;
//    QPoint point_pt;
//    int size = 2;
//    RetangleObject(QPoint _a, QPoint _b):m_startPoint(_a),m_endPoint(_b){}
//    ~RetangleObject();
//};

class GeoFactory
{
public:
    GeoFactory()=  default;
    static GeoObject* getGeoObject(GEO_TYPE type,const QPoint& m_begin,const QPoint& m_end){
        if (type == TYPE_LINE){
            return (new LineObject(m_begin,m_end));
        }
        else if (type == TYPE_TRANGLE){
            return (new RetangleObject(m_begin,m_end));
        }
    }
};


#endif //GEOMETERY_H_
